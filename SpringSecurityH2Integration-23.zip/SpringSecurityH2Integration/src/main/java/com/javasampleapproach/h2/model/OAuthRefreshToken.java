package com.javasampleapproach.h2.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "oauth_refresh_token")
public class OAuthRefreshToken {

	@Id
	private Long id;

	@Column
	private String token_id;
	@Column
	private Long token;
	@Column
	private Long authentication;

	public OAuthRefreshToken() {

	}

	public String getToken_id() {
		return token_id;
	}

	public void setToken_id(String token_id) {
		this.token_id = token_id;
	}

	public Long getToken() {
		return token;
	}

	public void setToken(Long token) {
		this.token = token;
	}

	public Long getAuthentication() {
		return authentication;
	}

	public void setAuthentication(Long authentication) {
		this.authentication = authentication;
	}

}
